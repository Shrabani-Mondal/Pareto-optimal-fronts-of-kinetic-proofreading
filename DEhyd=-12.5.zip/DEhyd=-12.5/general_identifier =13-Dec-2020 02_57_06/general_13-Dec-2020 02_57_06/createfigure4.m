%eta_pareto=0.0;
DDE=-5.21-(-6.5);

subplot(2,2,1)
load('general_m=2_2110.6.mat')
hold off
eta_h=1/(1+exp(2*DDE));
loglog((eta_pareto-eta_h), v_pareto,'MarkerFaceColor',[0.63 0.85 0.61],'Marker','square',...
    'MarkerSize',4,'Color',[0.63 0.85 0.61]);
% hold on
% load('general_m=2_2110.6.mat')
% eta_h=1/(1+exp(3*DDE));
% loglog((eta_pareto-eta_h), v_pareto,'MarkerFaceColor',[0.45 0.77 0.46],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.45 0.77 0.46]);
% load('general_m=2_2110.6.mat')
% eta_h=1/(1+exp(4*DDE));
% loglog((eta_pareto-eta_h), v_pareto,'MarkerFaceColor',[0.25 0.67 0.36],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.25 0.67 0.36]);
% load('general_m=2_2110.6.mat')
% eta_h=1/(1+exp(5*DDE));
% loglog((eta_pareto-eta_h), v_pareto,'MarkerFaceColor',[0.14 0.55 0.27],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.14 0.55 0.27]);
% % hold off
% load('ribosome_m=2_2061.1429.mat.mat')

% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.63 0.85 0.61],'Marker','square',...
  %  'MarkerSize',4,'Color',[0.63 0.85 0.61]);

% hold on
% load('symmetrized_fixed_energy_ver_2_m=7_2133.0554.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.45 0.77 0.46],'Marker','square',...
%     'MarkerSize',4, 'Color',[0.45 0.77 0.46])
% 
% load('symmetrized_fixed_energy_ver_2_m=8_2133.0554.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.25 0.67 0.36],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.25 0.67 0.36]);
% load('symmetrized_fixed_energy_ver_2_m=9_2133.0554.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.14 0.55 0.27],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.14 0.55 0.27]);
% 
% load('symmetrized_fixed_energy_ver_2_m=10_2133.0554.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0 0.35 0.2],'Marker','square',...
%    'MarkerSize',4, 'Color',[0 0.35 0.2]);
% 
% 
% 
% subplot(2,2,2)
% % load('symmetrized_fixed_energy_ver_2_m=2_2133.0554.mat')
% % hold off
% % loglog(eta_pareto.*2^(2/2.2), v_pareto*2^(2/2.2),'MarkerFaceColor',[0.63 0.85 0.61],'Marker','square',...
% %     'MarkerSize',4,'Color',[0.63 0.85 0.61]);
% % hold on
% % load('symmetrized_fixed_energy_ver_2_m=3_2133.0554.mat')
% % loglog(eta_pareto.*3^(3/2.2), v_pareto*3^(3/2.2),'MarkerFaceColor',[0.54 0.81 0.54],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.54 0.81 0.54]);
% % load('symmetrized_fixed_energy_ver_2_m=4_2133.0554.mat')
% % loglog(eta_pareto*4^(4/2.2), v_pareto*4^(4/2.2),'MarkerFaceColor',[0.45 0.77 0.46],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.45 0.77 0.46]);
% % load('symmetrized_fixed_energy_ver_2_m=5_2133.0554.mat')
% % loglog(eta_pareto.*5^(5/2.2), v_pareto*5^(5/2.2),'MarkerFaceColor',[0.35 0.72 0.41],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.35 0.72 0.41]);
% 
% load('symmetrized_fixed_energy_ver_2_m=6_2133.0554.mat')
% hold off
% loglog(eta_pareto.*6^(6/2.4), v_pareto*6^(0),'MarkerFaceColor',[0.63 0.85 0.61],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.63 0.85 0.61]);
% hold on
% load('symmetrized_fixed_energy_ver_2_m=7_2133.0554.mat')
% loglog(eta_pareto.*7^(7/2.4), v_pareto*7^(0),'MarkerFaceColor',[0.45 0.77 0.46],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.45 0.77 0.46]);
% 
% load('symmetrized_fixed_energy_ver_2_m=8_2133.0554.mat')
% loglog(eta_pareto*8^(8/2.4), v_pareto*8^(0),'MarkerFaceColor',[0.25 0.67 0.36],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.25 0.67 0.36]);
% load('symmetrized_fixed_energy_ver_2_m=9_2133.0554.mat')
% loglog(eta_pareto.*9^(9/2.4), v_pareto*9^(0),'MarkerFaceColor',[0.14 0.55 0.27],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.14 0.55 0.27]);
% 
% load('symmetrized_fixed_energy_ver_2_m=10_2133.0554.mat')
% loglog(eta_pareto.*10^(10/2.4), v_pareto*10^(0),'MarkerFaceColor',[0 0.35 0.2],'Marker','square',...
%    'MarkerSize',4, 'Color',[0 0.35 0.2]);
% 
% 
% subplot(2,2,3)
%  load('DEhy/symmetrized_fixed_energy_ver_2_m=10_8.1633.mat')
%  hold off
%  loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.62 0.79 0.88],'Marker','square',...
%      'MarkerSize',4,'Color',[0.62 0.79 0.88]);
% hold on
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_12.2449.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.42 0.68 0.84],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.42 0.68 0.84]);
% 
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_16.3265.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.26 0.57 0.78],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.26 0.57 0.78]);
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_24.4898.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.13 0.44 0.71],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.13 0.44 0.71]);
% 
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_32.6531.mat')
% loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.03 0.27 0.58],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.03 0.27 0.58]);
% 
% % load('DEhy/symmetrized_fixed_energy_ver_2_m=10_44.89.mat')
% % loglog(eta_pareto, v_pareto,'MarkerFaceColor',[0.03 0.27 0.58],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.03 0.27 0.58]);
% 
% % ll=10^-20;
% % ylim([ll, 1])
% 
% subplot(2,2,4)
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_8.1633.mat')
% hold off
%  loglog(eta_pareto*8.1633^4.6, v_pareto,'MarkerFaceColor',[0.62 0.79 0.88],'Marker','square',...
%    'MarkerSize',4,'Color',[0.62 0.79 0.88]);
% hold on
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_12.2449.mat')
% loglog(eta_pareto*12.2449^4.6, v_pareto,'MarkerFaceColor',[0.42 0.68 0.84],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.42 0.68 0.84]);
% 
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_16.3265.mat')
% loglog(eta_pareto*16.3265^4.6, v_pareto,'MarkerFaceColor',[0.26 0.57 0.78],'Marker','square',...
%    'MarkerSize',4, 'Color',[0.26 0.57 0.78]);
% load('DEhy/symmetrized_fixed_energy_ver_2_m=10_24.4898.mat')
%  loglog(eta_pareto*24.4898^4.6, v_pareto,'MarkerFaceColor',[0.13 0.44 0.71],'Marker','square',...
%     'MarkerSize',4, 'Color',[0.13 0.44 0.71]);
%  
%  load('DEhy/symmetrized_fixed_energy_ver_2_m=10_32.6531.mat')
%  loglog(eta_pareto*32.6531^(4.6), v_pareto,'MarkerFaceColor',[0.03 0.27 0.58],'Marker','square',...
%     'MarkerSize',4, 'Color',[0.03 0.27 0.58]);


% %  load('abc_d_1.mat')
% % % hold off
% % loglog(time(1,:), Mean(1,:), 'MarkerFaceColor',[0.74 0.74 0.74],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.74 0.74 0.74]);
% % hold on
% % loglog(time(2,:), Mean(2,:),'MarkerFaceColor',[0.59 0.59 0.59],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.59 0.59 0.59]);
% % loglog(time(3,:), Mean(3,:),'MarkerFaceColor',[0.45 0.45 0.45],'Marker','o',...
% %     'MarkerSize',4,'Color',[0.45 0.45 0.45]);
% % loglog(time(4,:), Mean(4,:),'MarkerFaceColor',[0.32 0.32 0.32],'Marker','o',...
% %     'MarkerSize',4,'Color',[0.32 0.32 0.32]);
% % loglog(time(5,:), Mean(5,:),'MarkerFaceColor',[0.15 0.15 0.15],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.15 0.15 0.15]);
% % 
% %  load('abc_d_10.mat')
% % % hold off
% % loglog(time(1,:), Mean(1,:),'MarkerFaceColor',[0.62 0.79 0.88],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.62 0.79 0.88]);
% % hold on
% % loglog(time(2,:), Mean(2,:),'MarkerFaceColor',[0.42 0.68 0.84],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.42 0.68 0.84]);
% % loglog(time(3,:), Mean(3,:),'MarkerFaceColor',[0.26 0.57 0.78],'Marker','^',...
% %     'MarkerSize',4,'Color',[0.26 0.57 0.78]);
% % loglog(time(4,:), Mean(4,:),'MarkerFaceColor',[0.13 0.44 0.71],'Marker','^',...
% %     'MarkerSize',4,'Color',[0.13 0.44 0.71]);
% % loglog(time(5,:), Mean(5,:),'MarkerFaceColor',[0.03 0.27 0.58],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.03 0.27 0.58]);
% % 
% % 
% % ylabel({'$h_{K}$'},'Interpreter','latex');
% % 
% % % Create xlabel
% % xlabel({'$ t$'},'Interpreter','latex');
% % 
% % 
% % subplot(1,2,2)
% % load('abc_d_01.mat')
% % hold off
% % loglog(time(1,:)*0.1*10^2, Mean(1,:)/10,'MarkerFaceColor',[0.63 0.85 0.61],'Marker','square',...
% %     'MarkerSize',4,'Color',[0.63 0.85 0.61]);
% % hold on
% % loglog(time(2,:)*0.1*100^2, Mean(2,:)/100,'MarkerFaceColor',[0.45 0.77 0.46],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.45 0.77 0.46]);
% % loglog(time(3,:)*0.1*1000^2, Mean(3,:)/1000,'MarkerFaceColor',[0.25 0.67 0.36],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.25 0.67 0.36]);
% % loglog(time(4,:)*0.1*10000^2, Mean(4,:)/10000,'MarkerFaceColor',[0.14 0.55 0.27],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0.14 0.55 0.27]);
% % loglog(time(5,:)*0.1*100000^2, Mean(5,:)/100000,'MarkerFaceColor',[0 0.35 0.2],'Marker','square',...
% %    'MarkerSize',4, 'Color',[0 0.35 0.2]);
% % 
% % %ylabel({'$h_{K}$'},'Interpreter','latex');
% % 
% % % Create xlabel
% % %xlabel({'$ t$'},'Interpreter','latex');
% % 
% % 
% %  load('abc_d_1.mat')
% % % hold off
% % loglog(time(1,:)*(1)*10^2, Mean(1,:)/10, 'MarkerFaceColor',[0.74 0.74 0.74],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.74 0.74 0.74]);
% % hold on
% % loglog(time(2,:)*(1)*100^2, Mean(2,:)/100,'MarkerFaceColor',[0.59 0.59 0.59],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.59 0.59 0.59]);
% % loglog(time(3,:)*(1)*1000^2, Mean(3,:)/1000,'MarkerFaceColor',[0.45 0.45 0.45],'Marker','o',...
% %     'MarkerSize',4,'Color',[0.45 0.45 0.45]);
% % loglog(time(4,:)*(1)*10000^2, Mean(4,:)/10000,'MarkerFaceColor',[0.32 0.32 0.32],'Marker','o',...
% %     'MarkerSize',4,'Color',[0.32 0.32 0.32]);
% % loglog(time(5,:)*(1)*100000^2, Mean(5,:)/100000,'MarkerFaceColor',[0.15 0.15 0.15],'Marker','o',...
% %    'MarkerSize',4, 'Color',[0.15 0.15 0.15]);
% % 
% %  load('abc_d_10.mat')
% % % hold off
% % loglog(time(1,:)*(10)*10^2, Mean(1,:)/10,'MarkerFaceColor',[0.62 0.79 0.88],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.62 0.79 0.88]);
% % hold on
% % loglog(time(2,:)*(10)*100^2, Mean(2,:)/100,'MarkerFaceColor',[0.42 0.68 0.84],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.42 0.68 0.84]);
% % loglog(time(3,:)*(10)*1000^2, Mean(3,:)/1000,'MarkerFaceColor',[0.26 0.57 0.78],'Marker','^',...
% %     'MarkerSize',4,'Color',[0.26 0.57 0.78]);
% % loglog(time(4,:)*(10)*10000^2, Mean(4,:)/10000,'MarkerFaceColor',[0.13 0.44 0.71],'Marker','^',...
% %     'MarkerSize',4,'Color',[0.13 0.44 0.71]);
% % loglog(time(5,:)*(10)*100000^2, Mean(5,:)/100000,'MarkerFaceColor',[0.03 0.27 0.58],'Marker','^',...
% %    'MarkerSize',4, 'Color',[0.03 0.27 0.58]);
% % 
% % 
% % 
% % ylabel({'$h_{K}/N$'},'Interpreter','latex');
% % 
% % % Create xlabel
% % xlabel({'$\kappa t N^2$'},'Interpreter','latex');
% % 
%end
 